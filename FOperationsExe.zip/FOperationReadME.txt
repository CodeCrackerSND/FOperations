Compute F = A xor (B or (Not C))
Get C bitmask from same formula knowing F, A, B

